#include "computerscientisttocomputer.h"

ComputerScientistToComputer::ComputerScientistToComputer()
{

}
