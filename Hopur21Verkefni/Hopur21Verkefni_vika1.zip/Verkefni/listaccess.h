#ifndef LISTACCESS_H
#define LISTACCESS_H

#include <iostream>
#include <csperson.h>
#include <vector>

using namespace std;

class ListAccess
{
    private:
        //vector<CSPerson> listOfCSPersons;
    public:
        //void addToList(CSPerson p);
        //vector<CSPerson> readFromFile();
        //void writeToFile();
        //vector<CSPerson> AddToVector();

};

#endif // LISTACCESS_H
