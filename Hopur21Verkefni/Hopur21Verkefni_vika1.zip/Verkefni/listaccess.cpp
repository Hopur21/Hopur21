#include "listaccess.h"
#include <iostream>
using namespace std;
/*
void ListAccess::addToList(CSPerson person)
{
    listOfCSPersons.push_back(person);
}

vector<CSPerson> ListAccess::readFromFile()
{
    // TODO implement.

    return null;
}

void ListAccess::writeToFile();
{

}*/

/* frá Dabs, athugar hvort aðili sé þegar í listanum -
 * struct PerformerComparison {
  bool operator() (Performer i,Performer j) { return (i.getName()<j.getName());}
};
*/

/*vector<CSPerson> ListAccess::AddToVector()
{

    return vectorOfCSPersons;
}*/
